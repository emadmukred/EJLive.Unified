package com.coder.toolbox.store

internal const val CODER_SSH_CONFIG_OPTIONS = "CODER_SSH_CONFIG_OPTIONS"

internal const val LAST_USED_URL = "lastDeploymentURL"

internal const val DEFAULT_URL = "defaultURL"

internal const val APP_NAME_AS_TITLE = "useAppNameAsTitle"

internal const val BINARY_SOURCE = "binarySource"

@Deprecated("Use BINARY_DESTINATION instead", replaceWith = ReplaceWith("BINARY_DESTINATION"))
internal const val BINARY_DIRECTORY = "binaryDirectory"

internal const val BINARY_DESTINATION = "binaryDestination"

internal const val DISABLE_SIGNATURE_VALIDATION = "disableSignatureValidation"

internal const val FALLBACK_ON_CODER_FOR_SIGNATURES = "signatureFallbackStrategy"

internal const val HTTP_CLIENT_LOG_LEVEL = "httpClientLogLevel"

internal const val DATA_DIRECTORY = "dataDirectory"

internal const val ENABLE_DOWNLOADS = "enableDownloads"

internal const val HEADER_COMMAND = "headerCommand"

internal const val TLS_CERT_PATH = "tlsCertPath"

internal const val TLS_KEY_PATH = "tlsKeyPath"

internal const val TLS_CA_PATH = "tlsCAPath"

internal const val TLS_ALTERNATE_HOSTNAME = "tlsAlternateHostname"

internal const val TLS_CERT_REFRESH_COMMAND = "tlsCertRefreshCommand"

internal const val DISABLE_AUTOSTART = "disableAutostart"

internal const val SSH_CONNECTION_TIMEOUT_IN_SECONDS = "sshConnectionTimeoutInSeconds"

internal const val ENABLE_SSH_WILDCARD_CONFIG = "enableSshWildcardConfig"

internal const val SSH_CONFIG_PATH = "sshConfigPath"

internal const val SSH_LOG_DIR = "sshLogDir"

internal const val SSH_CONFIG_OPTIONS = "sshConfigOptions"

internal const val NETWORK_INFO_DIR = "networkInfoDir"

internal const val WORKSPACE_VIEW_URL = "workspaceViewUrl"
internal const val WORKSPACE_CREATE_URL = "workspaceCreateUrl"

internal const val SSH_AUTO_CONNECT_PREFIX = "ssh_auto_connect_"

internal const val PREFER_OAUTH2_IF_AVAILABLE = "preferOAuth2IfAvailable"
